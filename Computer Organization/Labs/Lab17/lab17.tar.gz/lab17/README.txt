======================================================================
CS2110                        Lab 17                       Summer 2016
======================================================================
Read the instructions in the lab17.c file

First ensure you have the software required for HW08 installed (described in HW08 pdf)

cd into directory containing lab17.c and Makefile

Compile it with 'make'

Run it with 'make vba' 

When you are done, come show it to us then submit it on tsquare
