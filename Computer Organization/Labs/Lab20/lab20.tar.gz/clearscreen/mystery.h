#ifndef MYSTERY_BITMAP_H
#define MYSTERY_BITMAP_H

extern const unsigned short mystery[38400];
#define MYSTERY_WIDTH 240
#define MYSTERY_HEIGHT 160

#endif