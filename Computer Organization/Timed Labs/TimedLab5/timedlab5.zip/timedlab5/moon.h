#ifndef MOON_BITMAP_H
#define MOON_BITMAP_H
extern const unsigned short moon[38400];
#define MOON_WIDTH 240
#define MOON_HEIGHT 160
#endif