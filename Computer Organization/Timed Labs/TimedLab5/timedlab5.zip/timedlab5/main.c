// Name: YOUR NAME HERE

#include "myLib.h"
#include "moon.h"
#include "lor.h"

u16* videoBuffer = (unsigned short*) 0x6000000;

/* Image 1 */
#define NUM_ROW_CELL 4;
#define NUM_COL_CELL 2;
const unsigned short* image = moon;
const CELL cellA = {0,2};
const CELL cellB = {1,1};

/* Image 2 */
/*
#define NUM_ROW_CELL 2;
#define NUM_COL_CELL 2;
const unsigned short* image = lor;
const CELL cellA = {0,1};
const CELL cellB = {1,1};
*/

int main() {
	// TODO: Set REG_DISPCNT appropriately for drawing in mode 3

	
	// TODO: Call your functions to draw the swapped image onto the screen

	
	// Wait after drawing
	while (1);
	return 0;
}


/**
* Draws the whole image to videoBuffer.
*/
void drawFullScreenImage(const unsigned short* image) {
	//TODO: Implement this function
	
}


/**
* Draws srcCell from the image to dstCell in videoBuffer.
*/
void drawCell(const unsigned short* image, CELL srcCell, CELL dstCell) {
	// TODO: Implement this function
	
}
