#ifndef LOR_BITMAP_H
#define LOR_BITMAP_H
extern const unsigned short lor[38400];
#define LOR_WIDTH 240
#define LOR_HEIGHT 160
#endif