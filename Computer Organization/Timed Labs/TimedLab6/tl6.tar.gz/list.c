#include "list.h"
#include <stdio.h>
#include <stdlib.h>

/**
 * CS 2110 Timed Lab 6 Student Implementation
 * November 30, 2016
 * YOUR NAME HERE
 */

/**
 * This function will create a new linked list, initialize its fields and return a pointer to the list.
 */
LIST *create_list()
{
	return NULL;
}

/**
 * This function will create a node from the given data and return a pointer to that node.
 * If the data pointer is NULL, return NULL
 */
NODE *create_node(void* data)
{
	return NULL;
}

/**
 * This function will add a node with the given data pointer to the head of the linked list.
 * If the data pointer or list is NULL, return from the function gracefully.
 */
void push_front(LIST *llist, void* data)
{
	return;
}

/**
 * Removes the tail of the linked list and returns the data pointer from the removed node to the user.
 * If the list is empty or NULL, return NULL.
 */
void* pop_back(LIST *llist)
{
	return -1;
}

/**
 * All memory used in the linked list that was allocated from the heap should be freed. 
 * This includes all of the node structs in the linked list and the linked list struct.
 * The data pointed at by the data pointers in each node should be freed with free_func.
 * If the list is NULL, return from the function gracefully.
 */
void destroy(LIST *llist, list_op free_func)
{
	return;
}

/**
 * This function will return an array of the data pointers stored in the linked list.
 * Read the PDF for more information on this function.
 * If the list is empty or NULL, return NULL.
 */
void** to_array(LIST *llist)
{
	return NULL;
}
