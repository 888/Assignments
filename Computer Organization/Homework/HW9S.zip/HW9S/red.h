#ifndef RED_BITMAP_H
#define RED_BITMAP_H
extern const unsigned short red[625];
#define RED_WIDTH 25
#define RED_HEIGHT 25
#endif