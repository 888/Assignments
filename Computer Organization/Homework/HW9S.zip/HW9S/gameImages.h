/*
Name: Xiying Huang	
Date: 07/26/2016
*/

void drawTitleScreen();
void drawGameOverScreen();
void drawWinScreen();
void drawGameScreen();
void drawArchery(int row, int col);
void eraseArchery(int row, int col);
void drawShootingPoint(int archery_row, int archery_col);

void drawLife(char* ch);
void drawScore(char* ch);
void drawTime(char* ch);
