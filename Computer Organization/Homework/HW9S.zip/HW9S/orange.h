#ifndef ORANGE_BITMAP_H
#define ORANGE_BITMAP_H
extern const unsigned short orange[625];
#define ORANGE_WIDTH 25
#define ORANGE_HEIGHT 25
#endif