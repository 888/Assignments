#ifndef BONUS_BITMAP_H
#define BONUS_BITMAP_H
extern const unsigned short bonus[625];
#define BONUS_WIDTH 25
#define BONUS_HEIGHT 25
#endif