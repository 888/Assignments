#ifndef PINK_BITMAP_H
#define PINK_BITMAP_H
extern const unsigned short pink[625];
#define PINK_WIDTH 25
#define PINK_HEIGHT 25
#endif