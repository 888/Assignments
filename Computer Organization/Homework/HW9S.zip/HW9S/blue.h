#ifndef BLUE_BITMAP_H
#define BLUE_BITMAP_H
extern const unsigned short blue[625];
#define BLUE_WIDTH 25
#define BLUE_HEIGHT 25
#endif