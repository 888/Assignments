#ifndef GREEN_BITMAP_H
#define GREEN_BITMAP_H
extern const unsigned short green[625];
#define GREEN_WIDTH 25
#define GREEN_HEIGHT 25
#endif