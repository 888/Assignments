#ifndef HEART_BITMAP_H
#define HEART_BITMAP_H
extern const unsigned short heart[625];
#define HEART_WIDTH 25
#define HEART_HEIGHT 25
#endif