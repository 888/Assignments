#ifndef YELLOW_BITMAP_H
#define YELLOW_BITMAP_H
extern const unsigned short yellow[625];
#define YELLOW_WIDTH 25
#define YELLOW_HEIGHT 25
#endif