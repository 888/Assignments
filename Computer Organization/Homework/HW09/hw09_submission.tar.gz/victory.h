/*
 * Exported with nin10kit v1.3
 * Invocation command was nin10kit -mode=3 victory victory.jpg 
 * Time-stamp: Monday 11/07/2016, 18:22:43
 * 
 * Image Information
 * -----------------
 * victory.jpg 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef VICTORY_H
#define VICTORY_H

extern const unsigned short victory[38400];
#define VICTORY_SIZE 38400
#define VICTORY_WIDTH 240
#define VICTORY_HEIGHT 160

#endif

