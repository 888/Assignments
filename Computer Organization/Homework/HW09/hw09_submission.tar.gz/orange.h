#define ORANGE_WIDTH 25
#define ORANGE_HEIGHT 25
const unsigned short orange[625];
