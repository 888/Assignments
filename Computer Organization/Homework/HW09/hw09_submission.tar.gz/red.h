#define RED_WIDTH 25
#define RED_HEIGHT 25
const unsigned short red[625];
