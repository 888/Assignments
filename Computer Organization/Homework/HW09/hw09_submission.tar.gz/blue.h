#define BLUE_WIDTH 25
#define BLUE_HEIGHT 25
const unsigned short blue[625];
