/*
 * Exported with nin10kit v1.3
 * Invocation command was nin10kit -mode=3 title title.png 
 * Time-stamp: Monday 11/07/2016, 17:24:56
 * 
 * Image Information
 * -----------------
 * title.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * 
 * All bug reports / feature requests are to be sent to Brandon (bwhitehead0308@gmail.com)
 */

#ifndef TITLE_H
#define TITLE_H

extern const unsigned short title[38400];
#define TITLE_SIZE 38400
#define TITLE_WIDTH 240
#define TITLE_HEIGHT 160

#endif

