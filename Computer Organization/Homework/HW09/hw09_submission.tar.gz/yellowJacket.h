#ifndef YELLOWJACKET_BITMAP_H
#define YELLOWJACKET_BITMAP_H
extern const unsigned short yellowJacket[625];
#define YELLOWJACKET_WIDTH 25
#define YELLOWJACKET_HEIGHT 25
#endif
