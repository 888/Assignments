#define PINK_WIDTH 25
#define PINK_HEIGHT 25
const unsigned short pink[625];
