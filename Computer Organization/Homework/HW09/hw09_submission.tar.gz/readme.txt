Alan Chiang

BloonsTowerlessAttack

The objective of this game is to shoot the balloons, of which there are 9 types. The player has 30 seconds to shoot as many balloons as possible. 
Both Z and X will fire a shot if pressed. After a shot has been fired, the timer will pause while it travels. 
Pressing backspace at any time will return the game to its starting screen.

Six balloons will always be onscreen: the red, blue, green, pink, yellow, and orange ones. Shooting these balloons is worth 1 pt. 
After five seconds of playing, two more balloons will appear on the screen: the rainbow and heart balloons. Shooting the rainbow will give the player 5 pts but also cost the player 1 life. Shooting the heart will cause an instant loss.
The rainbow and heart balloons will stay on the screen for fifteen seconds.
After fifteen seconds of playing, a yellow jacket will appear on the screen. Shooting it will cause an instant win.

All balloons respawn immediately after being hit. 

Victory is achieved once the player reaches 15 points, or once the yellow jacket is hit. The player loses if time of lives run out.
