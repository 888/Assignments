#ifndef ARROW_BITMAP_H
#define ARROW_BITMAP_H
extern const unsigned short arrow[2000];
#define ARROW_WIDTH 50
#define ARROW_HEIGHT 40
#endif