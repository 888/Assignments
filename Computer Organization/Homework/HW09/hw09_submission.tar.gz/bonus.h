#define BONUS_WIDTH 25
#define BONUS_HEIGHT 25
const unsigned short bonus[625];
